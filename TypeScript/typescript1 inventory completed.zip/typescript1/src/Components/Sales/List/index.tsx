type salesOrder = {
  SellingItem: string;
  Quantity: number;
  Price: number
};

type props = {
  sellingItems: salesOrder[];
};

export default function SalesList({ sellingItems }: props) {
  return (
    <>
      <p className="mt-5 text-3xl text-yellow-300">List of sold Items</p>
   
        {sellingItems.map((Item: salesOrder) => (
          <div className="mt-4 border w-fit p-3 rounded">
            <p>
              Name:- {Item.SellingItem} <span className="mx-2"></span>
              Quantity Sold:- {Item.Quantity} <span className="mx-2"></span>
              Total Price:- {Item.Quantity * Item.Price}
            </p>
          </div>
        ))}
     
    </>
  );
}
