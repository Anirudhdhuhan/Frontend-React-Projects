import { useEffect, useState } from "react";

type itemsType = {
  Product: string;
  ID: string;
  Price: number;
  Quantity: number;
};

type salesOrder = {
  SellingItem: string;
  Quantity: number;
  Price: number;
};

type props = {
  itemsInStock: itemsType[];
  HandleList: (selectedValue: salesOrder) => void;
};

export default function SalesForm({ itemsInStock, HandleList }: props) {
  const [selectedValue, setSelectedValue] = useState<salesOrder>({
    SellingItem: "",
    Quantity: 0,
    Price: 0,
  });

  const HandleSelectedValue = (key: string, value: number | string) => {
    // if (key == "Quantity") {
    //   itemsInStock.find((row) => {
    //     if (row.Product == selectedValue.SellingItem) {
    //       if (row.Quantity >= +value) {
    //         return setSelectedValue({ ...selectedValue, Quantity: +value });
    //       } else {
    //         return setSelectedValue({ ...selectedValue, Quantity: 0 });
    //       }
    //     }
    //   });
    // } else {
      setSelectedValue({ ...selectedValue, [key]: value });
    // }
  };

  const foundItem = itemsInStock.find(
    (item) => item.Product == selectedValue.SellingItem
  );

  useEffect(() => {
    if (foundItem?.Price !== undefined) {
      setSelectedValue((prev) => ({ ...prev, Price: foundItem.Price }));
    }
  }, [foundItem]);

  return (
    <div>
      Select Selling Item:-
      <select
        className="border ml-2 bg-black pl-1 rounded"
        onChange={(e) => {
          HandleSelectedValue("SellingItem", e.target.value);
        }}
      >
        <option value="">Select</option>
        {itemsInStock.map((item) => (
          <option value={item.Product}>{item.Product}</option>
        ))}
      </select>
      <br /> <br />
      Enter Quantity:-{" "}
      <input
        type="number"
        className="border pl-1 rounded"
        onChange={(e) => {
          HandleSelectedValue("Quantity", e.target.value);
        }}
      />
      <button
        className="border px-2 rounded ml-2 hover:bg-green-700 hover:border-none"
        onClick={() => {
          HandleList(selectedValue);
        }}
      >
        Place Order
      </button>
      <br />
    </div>
  );
}
