import SalesForm from "./Form";
import SalesList from "./List";
import { useNavigate } from "react-router";

type itemsType = {
  Product: string;
  ID: string;
  Price: number;
  Quantity: number;
};

type salesOrder = {
  SellingItem: string;
  Quantity: number;
  Price: number
};

type props = {
  itemsInStock: itemsType[];
  HandleList: (selectedValue: salesOrder) => void;
  sellingItems: salesOrder[];
};

export default function Sales({ itemsInStock, HandleList, sellingItems }: props) {
  let navigate = useNavigate();
  return (
    <div className="ml-5">
      <button className="bg-gray-600 p-2 hover:bg-gray-700 rounded mt-5" onClick={()=>{navigate("/")}}>Home</button>
      <button className="bg-gray-600 p-2 hover:bg-gray-700 rounded mt-5 ml-2" onClick={()=>{navigate("/Inventory")}}>Inventory</button>
      <div className="ml-10 mt-4 mb-15  text-teal-500 text-5xl">Sales...</div>
      <SalesForm itemsInStock={itemsInStock} HandleList={HandleList} />
      <SalesList sellingItems={sellingItems}/>
    </div>
  );
}
