import { useState } from "react";

type itemType = {
  Product: string;
  ID: string;
  Price: number;
  Quantity: number;
};

type handleType = {
    HandleItemsInStock : (items:itemType) => void ;
  }

export default function InventoryForm({ HandleItemsInStock }: handleType) {
  const [typedItems, setTypedItems] = useState<itemType>({
    Product: "",
    ID: "",
    Price: 0,
    Quantity: 0    
  });

  function HandleTypedItems(name: string, e: any) {
    const value = e.target.value;
    setTypedItems({ ...typedItems, [name]: value });
  }


  return (
    <>
      <div className="m-4 ">
        <div className="flex mb-4 gap-4">
          <div>
            Product:-{" "}
            <input
              type="text"
              className="border pl-1 rounded"
              onChange={(e) => {
                HandleTypedItems("Product", e);
              }}
            />{" "}
          </div>
          <div>
            ID:-{" "}
            <input
              type="text"
              className="border pl-1 rounded"
              onChange={(e) => {
                HandleTypedItems("ID", e);
              }}
            />{" "}
          </div>
        </div>

        <div className="flex gap-4">
          <div>
            Price:-{" "}
            <input
              type="number"
              className="border pl-1 rounded"
              onChange={(e) => {
                HandleTypedItems("Price", e);
              }}
            />{" "}
          </div>
          <div>
            Quantity:-{" "}
            <input
              type="number"
              className="border pl-1 rounded"
              onChange={(e) => {
                HandleTypedItems("Quantity", e);
              }}
            />{" "}
          </div>
          <button
            className="border rounded p-1 ml-2 hover:bg-white hover:text-black"
            onClick={() => {
              HandleItemsInStock(typedItems);
            }}
          >
            Add Item
          </button>
        </div>
      </div>
    </>
  );
}
