type itemType = {
  Product: string;
  ID: string;
  Price: number;
  Quantity: number;
};

type ddeletebtn = {
  HandleDeleteBtn: (ID: string) => void;
};
type updateditemsType ={
  updateditems: itemType[];
}
type aall =  ddeletebtn & updateditemsType;

export default function InventoryList({ HandleDeleteBtn, updateditems }: aall) {
  return (
    <>
      {updateditems.map((row: itemType) => (
        <div className="flex">
          <div className="border p-3 rounded-xl ml-3 mb-4">
            <div className="flex gap-40 ml-4">
              <div>Product:- {row.Product}</div>
              <div>ID:- {row.ID}</div>
            </div>

            <div className="flex gap-40 ml-4">
              <div>Price:- {row.Price}</div>
              <div>Quantity:- {row.Quantity}</div>
            </div>
          </div>

          <button
            className="ml-4 border h-fit p-2 mt-4 rounded-xl hover:bg-red-500 hover:border-none"
            onClick={() => {
              HandleDeleteBtn(row.ID);
            }}
          >
            delete
          </button>
        </div>
      ))}
    </>
  );
}
