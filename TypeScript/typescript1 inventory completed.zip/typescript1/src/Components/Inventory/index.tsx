import { useNavigate } from "react-router";
import { helper } from "../helper.ts";
import InventoryForm from "./Form";
import InventoryList from "./List";

type itemType = {
  Product: string;
  ID: string;
  Price: number;
  Quantity: number;
};

type handleType = {
    HandleItemsInStock : (items:itemType) => void
  }

  type Props = {
    itemsInStock: itemType[];
  };

  type deletebtn ={
    HandleDeleteBtn: (ID:string) => void;
  }
  type salesOrder = {
    SellingItem: string;
    Quantity: number;
    Price: number;
  };

type sales = {
  sellingItems : salesOrder[];
}

type InventoryProps = handleType & Props & deletebtn & sales;


export default function Inventory({ HandleItemsInStock,itemsInStock,HandleDeleteBtn,sellingItems}: InventoryProps) {
  const updateditems: itemType[] = helper([...itemsInStock],[...sellingItems]);
  let navigate = useNavigate();
  return (
    <div>
      <button className="bg-gray-600 p-2 hover:bg-gray-700 rounded ml-5 mt-5" onClick={()=>{navigate("/")}}>Home</button>
      <button className="bg-gray-600 p-2 hover:bg-gray-700 rounded mt-5 ml-2" onClick={()=>{navigate("/Sales")}}>Sales</button>
    <div className="ml-10 mt-4 mb-15  text-teal-500 text-5xl">Inventory...</div>
      <InventoryForm HandleItemsInStock={HandleItemsInStock} />
      <InventoryList HandleDeleteBtn={HandleDeleteBtn} updateditems={updateditems}/>
    </div>
  ); 
}



