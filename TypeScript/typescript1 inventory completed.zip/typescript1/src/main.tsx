import { useState } from "react";
import { createBrowserRouter, RouterProvider } from "react-router";
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App.tsx";
import Inventory from "./Components/Inventory";
import Sales from "./Components/Sales";
import "./App.css";

function Root(){
  type itemsType = {
    Product: string;
    ID: string;
    Price: number;
    Quantity: number;
  };
  
  type salesOrder = {
    SellingItem: string;
    Quantity: number;
    Price: number;
  };
  
  const [itemsInStock, setItemsInStock] = useState<itemsType[]>([
    {
      Product: "Apple",
      ID: "001",
      Price: 50,
      Quantity: 1000,
    },
    {
      Product: "Mango",
      ID: "002",
      Price: 40,
      Quantity: 500,
    },
    {
      Product: "Orange",
      ID: "003",
      Price: 30,
      Quantity: 600,
    },
  ]);
  
  function HandleItemsInStock(items: itemsType): void {
    let bool: boolean = false;
    if (
      items.Product !== "" &&
      items.ID !== "" &&
      items.Price !== 0 &&
      items.Quantity !== 0
    ) {
      const ManageDuplicate = itemsInStock.map((item) => {
        if (item.ID === items.ID) {
          bool = true;
          return { ...item, Quantity: +items.Quantity + +item.Quantity };
        } else {
          return item;
        }
      });
  
      if (bool) {
        setItemsInStock(ManageDuplicate);
      } else {
        setItemsInStock([...itemsInStock, items]);
      }
    }
  }
  
  function HandleDeleteBtn(ID: string) {
    const remainingItems: itemsType[] = itemsInStock.filter(
      (item) => item.ID != ID
    );
    setItemsInStock(remainingItems);
  }
  
  const [sellingItems, setSellingItems] = useState<salesOrder[]>([]);
  
  function HandleList(item: salesOrder) {
    if (item.SellingItem != "" && item.Quantity != 0) {
      // inputs can not be null in Sales input
  
      const matchingInventoryRow: itemsType | undefined = itemsInStock.find(
        (row) => {
          if (row.Product == item.SellingItem) {
            return row;
          }
          return;
        }
      );
  
      if (!matchingInventoryRow) return;
  
      if (matchingInventoryRow?.Quantity < item.Quantity) {
        return;
      } else {
        setSellingItems([...sellingItems, item]);
      }
    }
  }
  
  const router = createBrowserRouter([
    {
      path: "/",
      element: <App />,
    },
    {
      path: "/Inventory",
      element: (
        <Inventory
          HandleItemsInStock={HandleItemsInStock}
          itemsInStock={itemsInStock}
          HandleDeleteBtn={HandleDeleteBtn}
          sellingItems={sellingItems}
        />
      ),
    },
    {
      path: "/Sales",
      element: (
        <Sales
          itemsInStock={itemsInStock}
          HandleList={HandleList}
          sellingItems={sellingItems}
        />
      ),
    },
  ]);
 return <RouterProvider router={router} />;
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
   <Root />
  </StrictMode>
);
